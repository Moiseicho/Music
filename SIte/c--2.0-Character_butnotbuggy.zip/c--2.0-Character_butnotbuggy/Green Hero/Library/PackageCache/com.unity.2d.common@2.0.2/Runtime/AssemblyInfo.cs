using System.Runtime.CompilerServices;
