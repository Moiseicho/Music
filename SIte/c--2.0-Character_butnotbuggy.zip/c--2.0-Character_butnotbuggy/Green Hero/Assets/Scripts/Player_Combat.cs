﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Player_Combat : MonoBehaviour
{
    void Update()
    {
        if (Input.GetMouseButtonDown(0))
        {
         //   void Attack();
        }
    }

    //void Attack()
    //{

    //}
}
